public class XY {
    public int[] Point = new int[2];
    public int C;
}